branch = 'fix'
nightly = True
official = True
version = '8.2.3.24061501'
version_name = '64bit Sensation'
